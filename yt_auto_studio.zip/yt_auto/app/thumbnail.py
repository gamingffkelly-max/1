import textwrap
from PIL import Image, ImageDraw, ImageEnhance, ImageFont
FONTS = ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/Library/Fonts/Arial Bold.ttf",
         "C:/Windows/Fonts/impact.ttf", "C:/Windows/Fonts/arialbd.ttf"]

def _font(size):
    for f in FONTS:
        try:
            return ImageFont.truetype(f, size)
        except Exception:
            pass
    return ImageFont.load_default()

def make(image_path, text, out, kind="long"):
    W, H = 1280, 720
    im = Image.open(image_path).convert("RGB")
    s = max(W / im.width, H / im.height)
    im = im.resize((int(im.width * s), int(im.height * s)), Image.LANCZOS)
    l, t = (im.width - W) // 2, (im.height - H) // 2
    im = im.crop((l, t, l + W, t + H))
    im = ImageEnhance.Color(ImageEnhance.Contrast(im).enhance(1.25)).enhance(1.3)
    ov = Image.new("RGBA", (W, H))
    od = ImageDraw.Draw(ov)
    for x in range(W):
        od.line([(x, 0), (x, H)], fill=(0, 0, 0, int(210 * max(0, 1 - x / (W * 0.8)))))
    im = Image.alpha_composite(im.convert("RGBA"), ov)
    d = ImageDraw.Draw(im)
    words = text.upper().split()
    lines = textwrap.wrap(" ".join(words), 12) or [""]
    size = 150 if len(lines) <= 2 else 118
    f = _font(size); y = (H - len(lines) * (size + 10)) // 2
    for i, line in enumerate(lines):
        col = (255, 214, 10) if i == len(lines) - 1 else (255, 255, 255)
        d.text((60, y), line, font=f, fill=col, stroke_width=10, stroke_fill=(0, 0, 0))
        y += size + 10
    d.rectangle([0, 0, W - 1, H - 1], outline=(255, 214, 10), width=8)
    im.convert("RGB").save(out, quality=94)
