import json, re, time, requests
from .config import CFG

def chat(prompt, system="", json_mode=False, temperature=0.8, retries=3):
    body = {"model": CFG["ollama"]["model"], "stream": False,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
            "options": {"temperature": temperature, "num_ctx": 8192}}
    if json_mode:
        body["format"] = "json"
    for i in range(retries):
        try:
            r = requests.post(CFG["ollama"]["host"] + "/api/chat", json=body, timeout=3600)
            r.raise_for_status()
            txt = r.json()["message"]["content"].strip()
            return json.loads(txt) if json_mode else txt
        except Exception:
            if i == retries - 1:
                raise
            time.sleep(5)

def clean(text):
    text = re.sub(r"[*#_`>]+", "", text)
    text = re.sub(r"\[[^\]]*\]|\([^)]*\)", "", text)
    lines = [l.strip() for l in text.splitlines() if l.strip()
             and not re.match(r"^(chapter|part|scene|narrator)\b", l.strip(), re.I)]
    return " ".join(lines)
