import os, yaml
from pathlib import Path
from dotenv import load_dotenv
ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")
CFG = yaml.safe_load(open(ROOT / "config.yaml", encoding="utf-8"))
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)
def env(k):
    v = os.getenv(k)
    if not v:
        raise RuntimeError(f"Missing {k} in .env")
    return v
