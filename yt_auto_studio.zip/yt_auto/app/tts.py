import subprocess
from .config import CFG, ROOT

def synth(text, out):
    m = ROOT / CFG["tts"]["piper_model"]
    if m.exists():
        subprocess.run(["piper", "--model", str(m), "--output_file", str(out)],
                       input=text.encode(), check=True, capture_output=True)
    else:
        subprocess.run(["espeak-ng", "-v", "en-us", "-s", "150", "-w", str(out), text],
                       check=True, capture_output=True)

def duration(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", str(path)], capture_output=True, text=True, check=True)
    return float(r.stdout.strip())
