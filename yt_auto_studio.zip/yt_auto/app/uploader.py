import time
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload
from google.oauth2.credentials import Credentials
from .config import CFG, env

SCOPES = ["https://www.googleapis.com/auth/youtube.upload", "https://www.googleapis.com/auth/youtube"]

def _yt():
    c = Credentials(None, refresh_token=env("YT_REFRESH_TOKEN"), client_id=env("YT_CLIENT_ID"),
                    client_secret=env("YT_CLIENT_SECRET"), token_uri="https://oauth2.googleapis.com/token", scopes=SCOPES)
    return build("youtube", "v3", credentials=c, cache_discovery=False)

def upload(video, thumb, meta, log):
    yt = _yt(); y = CFG["youtube"]
    def body(synth):
        st = {"privacyStatus": y["privacy"], "selfDeclaredMadeForKids": False}
        if synth:
            st["containsSyntheticMedia"] = True
        return {"snippet": {"title": meta["title"], "description": meta["description"], "tags": meta["tags"],
                            "categoryId": y["category_id"], "defaultLanguage": "en", "defaultAudioLanguage": "en"},
                "status": st}
    for synth in ([True, False] if y.get("disclose_synthetic") else [False]):
        try:
            req = yt.videos().insert(part="snippet,status", body=body(synth),
                                     media_body=MediaFileUpload(str(video), chunksize=64 * 1024 * 1024, resumable=True))
            resp, fails = None, 0
            while resp is None:
                try:
                    st, resp = req.next_chunk()
                    if st:
                        log(f"Upload {int(st.progress()*100)}%")
                except HttpError as e:
                    if e.resp.status in (500, 502, 503, 504) and fails < 8:
                        fails += 1; time.sleep(2 ** fails)
                    else:
                        raise
            break
        except HttpError as e:
            if synth and e.resp.status == 400:
                log("containsSyntheticMedia rejected; retrying without it"); continue
            raise
    vid = resp["id"]
    try:
        yt.thumbnails().set(videoId=vid, media_body=MediaFileUpload(str(thumb))).execute()
    except Exception as e:
        log(f"Thumbnail not set ({e}). Channel must be phone-verified.")
    return vid
