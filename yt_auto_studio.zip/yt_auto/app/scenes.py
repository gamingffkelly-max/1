import re
from . import llm
from .config import CFG

def build(chapters, kind):
    per = CFG[kind]["words_per_scene"]
    scenes = []
    for ci, ch in enumerate(chapters):
        buf, cnt = [], 0
        for s in re.split(r"(?<=[.!?])\s+", ch["text"]):
            if not s.strip():
                continue
            buf.append(s); cnt += len(s.split())
            if cnt >= per:
                scenes.append({"text": " ".join(buf), "chapter": ci}); buf, cnt = [], 0
        if buf:
            scenes.append({"text": " ".join(buf), "chapter": ci})
    for i in range(0, len(scenes), 12):
        batch = scenes[i:i + 12]
        listing = "\n".join(f"{j+1}. {s['text']}" for j, s in enumerate(batch))
        try:
            r = llm.chat("For each numbered narration line, write ONE vivid visual description (max 25 words) "
                         "of a cinematic scene illustrating it: characters, place, mood, camera angle. "
                         f"Return JSON {{\"prompts\":[...]}} with exactly {len(batch)} items.\n\n{listing}",
                         json_mode=True, temperature=0.7)["prompts"]
        except Exception:
            r = []
        for j, s in enumerate(batch):
            s["visual"] = r[j] if j < len(r) and isinstance(r[j], str) else s["text"][:150]
    return scenes
