import json, hashlib, random, re, time, feedparser, trafilatura
from .config import CFG, DATA

USED = DATA / "used.json"
EVERGREEN = [
    "Why compound interest is the most powerful force in personal finance",
    "How central banks quietly control your cost of living",
    "The hidden history of every major stock market crash",
    "Why most people never build wealth, and what the few do differently",
    "How inflation silently erases your savings",
]

def _used():
    return set(json.loads(USED.read_text())) if USED.exists() else set()

def mark_used(uid):
    u = _used(); u.add(uid); USED.write_text(json.dumps(sorted(u)))

def pick_topic():
    used, items = _used(), []
    for url in CFG["rss_feeds"]:
        try:
            d = feedparser.parse(url)
        except Exception:
            continue
        for e in d.entries[:30]:
            link = e.get("link")
            if not link:
                continue
            uid = hashlib.md5(link.encode()).hexdigest()
            if uid in used:
                continue
            ts = time.mktime(e.published_parsed) if e.get("published_parsed") else 0
            items.append({"id": uid, "title": e.get("title", ""), "link": link, "ts": ts,
                          "summary": re.sub(r"<[^>]+>", "", e.get("summary", ""))})
    if not items:
        t = random.choice(EVERGREEN)
        return {"id": hashlib.md5((t + str(time.time())).encode()).hexdigest(),
                "title": t, "summary": "", "text": "", "link": ""}
    items.sort(key=lambda x: x["ts"], reverse=True)
    topic = random.choice(items[:8])
    try:
        html = trafilatura.fetch_url(topic["link"])
        topic["text"] = (trafilatura.extract(html) or "")[:6000] if html else ""
    except Exception:
        topic["text"] = ""
    return topic
