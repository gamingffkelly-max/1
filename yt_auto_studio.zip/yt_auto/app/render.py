import math, subprocess, wave
from pathlib import Path
import numpy as np
from .config import CFG

def _ts(t):
    return f"{int(t//3600)}:{int(t%3600//60):02d}:{t%60:05.2f}"

def make_ass(scenes, kind, path):
    W, H = CFG[kind]["width"], CFG[kind]["height"]
    short = kind == "short"
    fs, ol, mv = (92, 7, 520) if short else (50, 3, 55)
    out = [f"[Script Info]\nScriptType: v4.00+\nPlayResX: {W}\nPlayResY: {H}\n\n[V4+ Styles]\n"
           "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,"
           "Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\n"
           f"Style: Main,{CFG['video']['font']},{fs},&H00FFFFFF,&H000000FF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,{ol},2,2,80,80,{mv},1\n\n"
           "[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text"]
    g, t = CFG[kind]["caption_words"], 0.0
    for sc in scenes:
        words = sc["text"].replace("{", "").replace("}", "").split()
        chunks = [words[i:i + g] for i in range(0, len(words), g)]
        wt = [sum(len(w) + 1 for w in c) for c in chunks]; tot = sum(wt) or 1
        cur = t
        for c, w in zip(chunks, wt):
            d = sc["dur"] * w / tot
            out.append(f"Dialogue: 0,{_ts(cur)},{_ts(cur+d)},Main,,0,0,0,,{' '.join(c)}")
            cur += d
        t += sc["dur"]
    Path(path).write_text("\n".join(out), encoding="utf-8")

def synth_music(path, secs=48):
    sr = 44100; t = np.arange(sr * secs) / sr
    chords = [[220, 261.63, 329.63], [174.61, 220, 261.63], [261.63, 329.63, 392], [196, 246.94, 293.66]]
    seg = secs / len(chords); out = np.zeros_like(t)
    for i, ch in enumerate(chords):
        m = (t >= i * seg) & (t < (i + 1) * seg); tt = t[m] - i * seg
        env = np.minimum(1, tt / 5) * np.minimum(1, (seg - tt) / 5)
        sig = sum(np.sin(2*math.pi*f*tt) + .5*np.sin(2*math.pi*f*1.003*tt) + .3*np.sin(math.pi*f*tt) for f in ch)
        out[m] = sig * env
    out *= 0.8 + 0.2 * np.sin(2 * math.pi * 0.1 * t)
    out = out / np.abs(out).max() * 0.5
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((out * 32767).astype(np.int16).tobytes())

def _enc():
    return (["-c:v", "h264_nvenc", "-preset", "p5", "-cq", "21"] if CFG["video"]["encoder"] == "h264_nvenc"
            else ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20"])

def _run(cmd, cwd=None):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError("ffmpeg failed: " + r.stderr[-800:])

def build(scenes, kind, work, final, log):
    work = Path(work); W, H, fps = CFG[kind]["width"], CFG[kind]["height"], CFG["video"]["fps"]
    clips = []
    for i, s in enumerate(scenes):
        n = int(math.ceil(s["dur"] * fps)); m = i % 3
        if m == 0:   z, x, y = f"1.0+0.15*on/{n}", "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)"
        elif m == 1: z, x, y = f"1.15-0.15*on/{n}", "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)"
        else:        z, x, y = "1.12", f"(iw-iw/zoom)*on/{n}", "ih/2-(ih/zoom/2)"
        vf = (f"scale={2*W}:{2*H},zoompan=z='{z}':x='{x}':y='{y}':d={n}:s={W}x{H}:fps={fps},format=yuv420p,"
              f"fade=t=in:st=0:d=0.2")
        c = work / f"clip_{i:04d}.mp4"
        _run(["ffmpeg", "-y", "-i", s["image"], "-i", s["audio"], "-vf", vf, "-af", "apad=pad_dur=0.3",
              *_enc(), "-c:a", "aac", "-ar", "44100", "-ac", "2", "-t", f"{s['dur']:.3f}", str(c)])
        clips.append(c)
        if i % 25 == 0:
            log(f"Clips {i+1}/{len(scenes)}")
    (work / "list.txt").write_text("".join(f"file '{c.name}'\n" for c in clips))
    _run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", "list.txt", "-c", "copy", "body.mp4"], cwd=work)
    make_ass(scenes, kind, work / "subs.ass"); synth_music(work / "music.wav")
    log("Final mix: grade + captions + music")
    fc = (f"[0:v]eq=contrast=1.06:saturation=1.12,vignette=PI/5,ass=subs.ass[v];"
          f"[1:a]volume={CFG['video']['music_volume']}[m];[0:a][m]amix=inputs=2:duration=first:dropout_transition=0[a]")
    enc = _enc()
    if enc[1] == "libx264":
        enc = ["-c:v", "libx264", "-preset", "medium", "-crf", "19"]
    _run(["ffmpeg", "-y", "-i", "body.mp4", "-stream_loop", "-1", "-i", "music.wav", "-filter_complex", fc,
          "-map", "[v]", "-map", "[a]", *enc, "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart",
          "-shortest", str(Path(final).resolve())], cwd=work)
