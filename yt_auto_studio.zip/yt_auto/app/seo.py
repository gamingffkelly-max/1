import re
from . import llm

def _ts(sec):
    return f"{int(sec//3600)}:{int(sec%3600//60):02d}:{int(sec%60):02d}" if sec >= 3600 else f"{int(sec//60)}:{int(sec%60):02d}"

def make(topic, chapters, starts, kind, script_text):
    j = llm.chat("Create YouTube SEO metadata (English) for a cinematic finance video.\n"
                 f"Topic: {topic['title']}\nNarration excerpt: {script_text[:1800]}\n"
                 'Return JSON: {"title":"<=65 chars, curiosity + keyword, no clickbait lies",'
                 '"summary":"2 engaging paragraphs, keyword-rich","tags":["15 tags"],'
                 '"thumb_text":"2-4 punchy words","hashtags":["3 hashtags without #"]}', json_mode=True, temperature=0.6)
    title = re.sub(r"\s+", " ", str(j.get("title") or topic["title"])).strip()[:90]
    tags, total = [], 0
    for t in j.get("tags", []):
        t = str(t)[:40]
        if total + len(t) < 450:
            tags.append(t); total += len(t) + 1
    hs = [h.strip("# ") for h in j.get("hashtags", [])][:3]
    if kind == "short":
        hs = ["Shorts"] + [h for h in hs if h.lower() != "shorts"][:2]
        if "#shorts" not in title.lower() and len(title) < 90:
            title += " #Shorts"
    desc = str(j.get("summary", "")).strip() + "\n\n"
    if kind == "long" and len(chapters) >= 3:
        desc += "Chapters:\n" + "\n".join(f"{_ts(s)} {c['title']}" for c, s in zip(chapters, starts)) + "\n\n"
    desc += ("This video is for educational and entertainment purposes only and is not financial advice. "
             "Visuals and narration are AI-generated.\n\n" + " ".join("#" + h for h in hs))
    return {"title": title, "description": desc[:4900], "tags": tags,
            "thumb_text": str(j.get("thumb_text") or " ".join(title.split()[:3]))}
