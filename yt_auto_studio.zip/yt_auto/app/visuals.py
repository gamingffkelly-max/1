import hashlib, random
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
from .config import CFG

_pipe = None
def _get_pipe():
    global _pipe
    if _pipe is None:
        import torch
        from diffusers import AutoPipelineForText2Image
        _pipe = AutoPipelineForText2Image.from_pretrained(
            CFG["images"]["model"], torch_dtype=torch.float16, variant="fp16").to("cuda")
    return _pipe

def _procedural(w, h, seed):
    r = random.Random(seed)
    c1 = tuple(r.randint(20, 120) for _ in range(3)); c2 = tuple(r.randint(120, 255) for _ in range(3))
    im = Image.new("RGB", (w, h)); d = ImageDraw.Draw(im)
    for y in range(h):
        k = y / h
        d.line([(0, y), (w, y)], fill=tuple(int(c1[i] * (1 - k) + c2[i] * k) for i in range(3)))
    cx, cy = r.randint(w // 4, 3 * w // 4), int(h * 0.38)
    glow = Image.new("RGB", (w, h), (0, 0, 0))
    ImageDraw.Draw(glow).ellipse([cx - 160, cy - 160, cx + 160, cy + 160], fill=(255, 220, 140))
    im = Image.blend(im, glow.filter(ImageFilter.GaussianBlur(90)), 0.35)
    d = ImageDraw.Draw(im); x = 0
    while x < w:
        bw, bh = r.randint(w // 25, w // 9), r.randint(h // 8, int(h * 0.5))
        d.rectangle([x, h - bh, x + bw, h], fill=(12, 14, 28)); x += bw + 4
    return im

def generate(scenes, work, kind, log):
    w, h = (1024, 576) if kind == "long" else (576, 1024)
    tw, th = CFG[kind]["width"], CFG[kind]["height"]
    pipe = None
    try:
        pipe = _get_pipe(); log("Image model loaded (local GPU)")
    except Exception as e:
        log(f"Local image model unavailable ({type(e).__name__}); using procedural visuals")
    for i, s in enumerate(scenes):
        seed = int(hashlib.md5(s["text"].encode()).hexdigest()[:8], 16)
        if pipe:
            import torch
            im = pipe(prompt=f"{s['visual']}, {CFG['images']['style']}",
                      num_inference_steps=CFG["images"]["steps"], guidance_scale=CFG["images"]["guidance"],
                      width=w, height=h, generator=torch.Generator("cuda").manual_seed(seed)).images[0]
        else:
            im = _procedural(w, h, seed)
        p = Path(work) / f"img_{i:04d}.jpg"
        im.resize((tw, th), Image.LANCZOS).save(p, quality=92)
        s["image"] = str(p)
        if i % 25 == 0:
            log(f"Images {i+1}/{len(scenes)}")
