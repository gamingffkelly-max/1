import json, random, shutil, time
from pathlib import Path
from . import rss, script, scenes as sc, visuals, tts, render, thumbnail, seo, uploader
from .config import CFG, DATA

def run(kind, log):
    jid = time.strftime("%Y%m%d_%H%M%S") + "_" + kind
    work, out = DATA / "work" / jid, DATA / "output" / jid
    work.mkdir(parents=True); out.mkdir(parents=True)
    log(f"=== {kind.upper()} job {jid} ===")
    topic = rss.pick_topic(); rss.mark_used(topic["id"]); log(f"Topic: {topic['title']}")
    if kind == "long":
        lo, hi = CFG["long"]["minutes"]; chapters = script.long_script(topic, random.randint(lo, hi))
    else:
        chapters = script.short_script(topic, CFG["short"]["seconds"])
    full = " ".join(c["text"] for c in chapters)
    log(f"Script ready: {len(full.split())} words")
    scenes = sc.build(chapters, kind); log(f"{len(scenes)} scenes")
    visuals.generate(scenes, work, kind, log)
    for i, s in enumerate(scenes):
        s["audio"] = str(work / f"v_{i:04d}.wav"); tts.synth(s["text"], s["audio"])
        s["dur"] = tts.duration(s["audio"]) + 0.3
        if i % 25 == 0:
            log(f"Voice {i+1}/{len(scenes)}")
    t, starts, seen = 0.0, [], set()
    for s in scenes:
        if s["chapter"] not in seen:
            seen.add(s["chapter"]); starts.append(t)
        t += s["dur"]
    log(f"Runtime: {t/60:.1f} min")
    video = out / "video.mp4"
    render.build(scenes, kind, work, video, log)
    meta = seo.make(topic, chapters, starts, kind, full)
    thumb = out / "thumb.jpg"
    thumbnail.make(scenes[min(len(scenes) // 3, len(scenes) - 1)]["image"], meta["thumb_text"], thumb, kind)
    (out / "meta.json").write_text(json.dumps(meta, indent=2))
    log(f"Uploading: {meta['title']}")
    vid = uploader.upload(video, thumb, meta, log)
    log(f"PUBLISHED https://youtu.be/{vid}")
    if not CFG["keep_work_files"]:
        shutil.rmtree(work, ignore_errors=True)
    return vid
