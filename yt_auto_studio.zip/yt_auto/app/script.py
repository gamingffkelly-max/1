from . import llm
from .config import CFG

SYS = ("You are an award-winning documentary screenwriter for a cinematic finance YouTube channel. "
       "Write ONLY spoken narration in plain English prose: no headings, no markdown, no stage directions, "
       "no lists. Tell it as a gripping story with characters, stakes, turning points and deep, accurate analysis. "
       "Never give personalised financial advice. Do not copy source text; transform it into original storytelling.")

def _ctx(topic):
    return f"Headline: {topic['title']}\nSource notes: {(topic['text'] or topic['summary'])[:3500]}"

def _write(topic, title, brief, target, prev_tail, first, last):
    text = ""
    for _ in range(5):
        need = target - len(text.split())
        if need < target * 0.12:
            break
        p = (f"{_ctx(topic)}\n\nSection: {title}\nPurpose: {brief}\n"
             f"Previous narration ended with: \"{(prev_tail + ' ' + text)[-500:]}\"\n"
             f"Write about {min(need, 700)} more words of narration that continue seamlessly. "
             f"{'Open with a powerful hook.' if first and not text else ''} "
             f"{'End with a memorable conclusion and a thought-provoking close.' if last and need < 700 else 'Do not conclude yet.'}")
        text += " " + llm.clean(llm.chat(p, SYS))
    return text.strip()

def long_script(topic, minutes):
    total = int(minutes * CFG["narration_wpm"])
    n = max(8, round(total / CFG["words_per_chapter"]))
    o = llm.chat(f"{_ctx(topic)}\n\nPlan a {minutes}-minute cinematic documentary in exactly {n} chapters "
                 f"that goes deep: origins, key players, mechanics, turning points, hidden risks, global impact, "
                 f"lessons. Return JSON: {{\"chapters\":[{{\"title\":\"...\",\"brief\":\"...\"}}]}}",
                 SYS, json_mode=True)
    chs = o.get("chapters", [])[:n]
    while len(chs) < n:
        chs.append({"title": f"Deeper Analysis {len(chs)+1}", "brief": "Expand with new angles, data and stories."})
    out, tail = [], ""
    for i, c in enumerate(chs):
        t = _write(topic, c["title"], c["brief"], total // n, tail, i == 0, i == n - 1)
        out.append({"title": c["title"], "text": t}); tail = t
    return out

def short_script(topic, seconds):
    words = int(seconds * CFG["narration_wpm"] / 60)
    p = (f"{_ctx(topic)}\n\nWrite a {words}-word narration for a YouTube Short. First sentence must be a shocking "
         f"hook. Fast, vivid, story-like, ends with a surprising insight. Return ONLY the narration.")
    return [{"title": "Short", "text": llm.clean(llm.chat(p, SYS))}]
