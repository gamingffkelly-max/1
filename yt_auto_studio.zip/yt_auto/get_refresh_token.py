"""One-time: run on a machine with a browser to obtain YT_REFRESH_TOKEN."""
import os
from dotenv import load_dotenv
from google_auth_oauthlib.flow import InstalledAppFlow
load_dotenv()
cfg = {"installed": {"client_id": os.environ["YT_CLIENT_ID"], "client_secret": os.environ["YT_CLIENT_SECRET"],
       "auth_uri": "https://accounts.google.com/o/oauth2/auth", "token_uri": "https://oauth2.googleapis.com/token",
       "redirect_uris": ["http://localhost"]}}
flow = InstalledAppFlow.from_client_config(cfg, ["https://www.googleapis.com/auth/youtube.upload",
                                                 "https://www.googleapis.com/auth/youtube"])
c = flow.run_local_server(port=0, access_type="offline", prompt="consent")
print("\nYT_REFRESH_TOKEN=" + c.refresh_token)
