import queue, threading, time, traceback
from collections import deque
from flask import Flask, jsonify, render_template
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from app.config import CFG
from app import pipeline

web = Flask(__name__)
Q = queue.Queue()
S = {"running": None, "queued": [], "log": deque(maxlen=400)}

def log(m):
    S["log"].append(f"[{time.strftime('%H:%M:%S')}] {m}"); print(m, flush=True)

def worker():
    while True:
        kind, why = Q.get()
        S["queued"].remove(f"{kind} ({why})"); S["running"] = f"{kind} ({why})"
        try:
            pipeline.run(kind, log)
        except Exception:
            log("FAILED:\n" + traceback.format_exc())
        S["running"] = None

def enqueue(kind, why):
    S["queued"].append(f"{kind} ({why})"); Q.put((kind, why)); log(f"Queued {kind} ({why})")

@web.route("/")
def index():
    return render_template("index.html")

@web.post("/run/<kind>")
def run_now(kind):
    if kind not in ("long", "short"):
        return jsonify(error="bad kind"), 400
    enqueue(kind, "manual"); return jsonify(ok=True)

@web.get("/status")
def status():
    return jsonify(running=S["running"], queued=S["queued"], log=list(S["log"])[-80:],
                   schedule=CFG["schedule"], tz=CFG["timezone"])

if __name__ == "__main__":
    threading.Thread(target=worker, daemon=True).start()
    sch = BackgroundScheduler(timezone=CFG["timezone"])
    for kind, times in CFG["schedule"].items():
        for hm in times:
            h, m = map(int, hm.split(":"))
            sch.add_job(enqueue, CronTrigger(hour=h, minute=m, timezone=CFG["timezone"]), args=[kind, "auto"],
                        id=f"{kind}-{hm}", misfire_grace_time=3600, coalesce=True)
    sch.start(); log("Scheduler started")
    web.run(host=CFG["dashboard"]["host"], port=CFG["dashboard"]["port"], threaded=True)
