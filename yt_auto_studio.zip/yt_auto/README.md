# YT Auto Studio — সম্পূর্ণ লোকাল ইউটিউব অটোমেশন

RSS → লোকাল AI স্ক্রিপ্ট → লোকাল ভয়েস → লোকাল ছবি → সিনেমাটিক ভিডিও → থাম্বনেইল → SEO → ইউটিউবে পাবলিশ।
কোনো থার্ড-পার্টি AI API নেই। শুধু ইউটিউবে আপলোডের জন্য আপনার Client ID / Secret / Refresh Token।

## সময়সূচি (config.yaml)
- লং ভিডিও (১ ঘ ৪৫ মি – ২ ঘ): রাত ১২:০০ ও দুপুর ১২:০০
- শর্ট: সকাল ৬:০০ ও সন্ধ্যা ৬:০০
- ড্যাশবোর্ডের বাটনে ক্লিক করলে সাথে সাথে চালু হয়ে পাবলিশ হবে।
- একটি জব চলাকালীন আরেকটি এলে কিউতে অপেক্ষা করে।

## সেটআপ
1. `pip install -r requirements.txt` (GPU থাকলে torch, diffusers, transformers, accelerate; ভয়েসের জন্য piper-tts)
2. ffmpeg ইনস্টল করুন।
3. Ollama ইনস্টল করে: `ollama pull llama3.1:8b`
4. Piper ভয়েস `en_US-ryan-high.onnx` (+ .json) `models/` ফোল্ডারে রাখুন।
5. `.env.example` কপি করে `.env` বানান, YT_CLIENT_ID ও YT_CLIENT_SECRET বসান।
6. `python get_refresh_token.py` চালিয়ে YT_REFRESH_TOKEN নিয়ে `.env`-এ বসান।
   (Google Cloud Console → YouTube Data API v3 চালু করুন → OAuth Desktop client)
7. `python main.py` → ব্রাউজারে `http://localhost:8080`

## জানা দরকার
- ১৫ মিনিটের বেশি ভিডিও ও কাস্টম থাম্বনেইলের জন্য চ্যানেল ফোন-ভেরিফাইড হতে হবে।
- ডিফল্ট কোটায় (১০,০০০/দিন) প্রতি আপলোড ১৬০০ ইউনিট, দিনে ৪টি আপলোড নিরাপদ।
- GPU না থাকলে ছবি সাধারণ প্রসিজুরাল ডিজাইনে হবে। সিনেমাটিক ছবির জন্য NVIDIA GPU (৮GB+) লাগবে।
- ২ ঘন্টার ভিডিও বানাতে অনেক ঘণ্টা লাগতে পারে। পরের জব কিউতে থাকবে।
- ইউটিউব AI-জেনারেটেড কনটেন্ট ডিসক্লোজার চায়; কোডে তা অন করা আছে (`disclose_synthetic`)।
  একই ধাঁচের বিপুল পরিমাণ কনটেন্টে "repetitious content" নীতির ঝুঁকি আছে। গল্প ও বিষয় বৈচিত্র্যময় রাখুন।
